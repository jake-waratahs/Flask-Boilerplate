from ClassyViewExample import ClassyViewExample
from Index import Index
from SampleForm import SampleForm
from UploadsView import UploadsView
