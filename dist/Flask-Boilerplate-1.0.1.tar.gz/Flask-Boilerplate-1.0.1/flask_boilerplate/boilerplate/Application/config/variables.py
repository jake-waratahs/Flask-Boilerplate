# Global & Security
APP_NAME='boilerplate'
DB_BASE = 'boilerplate'
SECRET_KEY = 'change_me'
SECURITY_PASSWORD_SALT = 'change_me'

# Production Specific
SENTRY_DSN = ''
PRODUCTION_DB_DRIVER = 'mysql'
PRODUCTION_DB_USER = ''
PRODUCTION_DB_PASSWORD = ''
PRODUCTION_DB_DATABASE = ''

# SMTP Stuff
MAIL_SERVER = 'smtp.gmail.com'
MAIL_PORT = 587
MAIL_USE_SSL = True
MAIL_USERNAME = ''
MAIL_PASSWORD = ''

# Babel Configuration
BABEL_DEFAULT_LOCALE = 'en'
BABEL_DEFAULT_TIMEZONE = 'AEST'



